export default function handleClickWithoutDrag(element, callback){
	
		this._element.addEventListener('mousedown', );
}