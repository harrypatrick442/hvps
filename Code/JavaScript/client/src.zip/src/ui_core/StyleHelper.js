import i from './i';
import E from './E';
export default class StyleHelper{
	static set(){}
}