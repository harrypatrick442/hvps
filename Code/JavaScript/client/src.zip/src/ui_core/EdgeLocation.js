﻿const EdgeLocation={ TOP_LEFT:'top-left',TOP_CENTER:'top-center', TOP_RIGHT:'top-right', MIDDLE_RIGHT:'middle-right',
BOTTOM_RIGHT:'bottom-right', BOTTOM_CENTER:'bottom-center', BOTTOM_LEFT:'bottom-lefft', MIDDLE_LEFT:'middle-left'};
export default EdgeLocation;