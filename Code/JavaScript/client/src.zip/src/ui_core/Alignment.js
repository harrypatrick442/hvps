const Alignment ={left:'left', right:'right', top:'top', bottom:'bottom'};
export default Alignment;