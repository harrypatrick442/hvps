export default class ImageHelper{
	
}