import Icons from '../icons/Icons';
export default function i(name){
	return Icons.get(name);
}