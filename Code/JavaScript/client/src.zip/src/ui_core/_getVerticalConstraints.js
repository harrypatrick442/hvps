export default function _getVerticalConstraints(element, bottomElseTop, rightElseLeft){
	const height = element.offsetHeight;
	const width = element.offsetWidth;
	if(bottomElseTop){
		
	}
}