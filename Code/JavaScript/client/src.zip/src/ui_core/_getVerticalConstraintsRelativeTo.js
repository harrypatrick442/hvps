export default function _getVerticalConstraintsRelativeTo(){
	
}