import VirtualSockets from '../virtual_sockets/VirtualSockets';
const NativeVirtualSockets = new VirtualSockets();
export default NativeVirtualSockets;