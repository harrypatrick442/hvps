export default class NativeStorageSetStringResponse
{
 static fromJSON(o){
    const r = {};
   return r;
 }
}