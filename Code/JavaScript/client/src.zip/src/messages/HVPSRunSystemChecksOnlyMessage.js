export default class HVPSRunSystemChecksOnlyMessage
{
 static toJSON(o){ 
    const r = {};
   r["tpe"]="rsco";
    return r;
 }
 static fromJSON(o){
    const r = {};
   return r;
 }
}