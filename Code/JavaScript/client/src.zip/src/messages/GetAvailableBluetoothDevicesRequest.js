export default class GetAvailableBluetoothDevicesRequest
{
 static toJSON(o){ 
    const r = {};
   r["tpe"]="gabd";
    return r;
 }
}