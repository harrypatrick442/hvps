export default class NativeStorageDeleteAllRequest
{
 static toJSON(o){ 
    const r = {};
   r["tpe"]="nsda";
    return r;
 }
}