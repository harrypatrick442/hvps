export default class NativeStorageDeleteAllResponse
{
 static fromJSON(o){
    const r = {};
   return r;
 }
}