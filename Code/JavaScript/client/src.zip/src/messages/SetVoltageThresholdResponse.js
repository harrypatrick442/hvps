export default class SetVoltageThresholdResponse
{
 static fromJSON(o){
    const r = {};
   return r;
 }
}