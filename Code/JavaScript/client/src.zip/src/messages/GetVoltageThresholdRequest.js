export default class GetVoltageThresholdRequest
{
 static toJSON(o){ 
    const r = {};
   r["tpe"]="gvf";
    return r;
 }
}