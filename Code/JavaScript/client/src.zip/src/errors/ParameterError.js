﻿import ExtendableError from './ExtendableError';
export default class ParameterError extends ExtendableError {

}