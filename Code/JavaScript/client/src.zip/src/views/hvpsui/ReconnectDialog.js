export default class ReconnectDialog{
	constructor(){
	}
	get element(){
		return this._element;
	}
}