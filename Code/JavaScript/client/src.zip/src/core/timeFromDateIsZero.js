export default function timeFromDateIsZero(date){
	return (hours<1)&&(minutes<1)&&(seconds<1);
}