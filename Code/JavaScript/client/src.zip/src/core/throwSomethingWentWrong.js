﻿export default function throwSomethingWentWrong (){
	throw new Error('Something went very wrong');
}