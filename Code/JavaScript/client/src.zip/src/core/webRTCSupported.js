const webRTCSupported = window.RTCPeerConnection?true:false;
export default webRTCSupported;