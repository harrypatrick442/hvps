export default function isNullOrUndefinedOrEmptyString(value){
	return value===undefined||value===null||value==='';
}