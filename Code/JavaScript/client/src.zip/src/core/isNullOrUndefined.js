export default function isNullOrUndefined(value){
	return value===undefined||value===null;
}