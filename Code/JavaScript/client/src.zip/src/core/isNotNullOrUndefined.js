import isNullOrUndefined from './isNullOrUndefined';
export default function isNotNullOrUndefined(value){
	return !isNullOrUndefined(value);
}