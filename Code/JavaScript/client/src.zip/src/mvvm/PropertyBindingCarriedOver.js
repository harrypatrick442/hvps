export default function PropertyBindingCarriedOver(propertyBindingSource, propertyBindingCarriedOver){
	this.getSource=()=>propertyBindingSource;
	this.getCarriedOver=()=>propertyBindingCarriedOver;
}