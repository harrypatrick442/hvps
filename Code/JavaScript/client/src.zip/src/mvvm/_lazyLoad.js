import PropertyBindingFactory from './PropertyBindingFactory';
export default function _lazyLoad(me, model, propertyName, createView){
	PropertyBindingFactory.standard(me, model, propertyName, (value)=>{
		if(
	});
};